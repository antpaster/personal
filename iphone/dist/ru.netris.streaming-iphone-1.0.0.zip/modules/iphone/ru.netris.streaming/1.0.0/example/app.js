var streamModule = require('ru.netris.streaming');

var streamModuleFinder = streamModule.createFinder();
